// jest.config.js
export default {
  testEnvironment: "node",
  transform: {}, // keep this to prevent Jest from trying to use Babel
};
